BENEATH THE SURFACE - Mystery Finder
=====================================
A browser-based hot & cold exploration game set in a dark cave.

HOW TO PLAY
-----------
- Move using WASD or Arrow Keys
- Click anywhere on the cave to move there
- Follow the temperature hints to find the hidden relic:
    "Warmer"      = you're getting closer
    "Colder"      = you're moving away
    "Much warmer" = very close now!
- Find the relic to win!

CONTROLS
--------
W / Arrow Up    - Move up
S / Arrow Down  - Move down
A / Arrow Left  - Move left
D / Arrow Right - Move right
Mouse Click     - Move toward click point

TIPS
----
- Watch the torch light — it shifts color as you get closer
- The cave has dust and rock formations but no walls to block you
- Try to find the relic in as few steps as possible!

TECHNICAL
---------
- Pure HTML5 + Canvas, no dependencies
- Works in any modern browser (Chrome, Firefox, Safari, Edge)
- No install needed

VERSION
-------
v1.0 - Initial release
