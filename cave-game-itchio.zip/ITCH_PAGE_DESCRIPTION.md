# Beneath the Surface — Mystery Finder

**Something ancient sleeps in the dark. Can you find it?**

---

## About the Game

You descend alone into a forgotten cave, torch in hand. Somewhere in the darkness, a relic lies hidden — waiting to be uncovered after centuries of silence.

You have no map. No compass. Only instinct... and temperature.

Move through the cave and listen to your surroundings:
- **"Warmer…"** — you're on the right track
- **"Colder…"** — turn back
- **"Much warmer…!"** — it's close. Very close.

When you find it, you win. How few steps can you manage?

---

## How to Play

| Control | Action |
|---|---|
| WASD or Arrow Keys | Move player |
| Mouse Click | Move toward click point |

No installation needed — runs entirely in your browser.

---

## Features

- 🕯️ Dynamic torch lighting that shifts color as you approach the relic
- 💨 Atmospheric cave with floating dust, stalactites & stalagmites
- 🌡️ Hot & cold proximity hint system
- 🖱️ Keyboard and mouse controls
- 🔁 Infinite replayability — relic location is random every run
- 📊 Step counter to track and beat your personal best

---

## Tips

- The torch glow around your character subtly warms in hue as you get closer — use it as a visual clue
- The relic pulses faintly, but only reveals itself when you're very near
- Challenge yourself: try to find the relic in under 20 steps!

---

*Made with HTML5 Canvas. No frameworks. No libraries. Just code.*
